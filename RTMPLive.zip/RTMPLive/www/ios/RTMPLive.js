
var
    exec = require('cordova/exec')
;


var Play = function() {
};

Play.play = function(play_type,play_url) {
    exec(function () {
        alert("success");
    }, function (error_essage) {
        alert(error_essage)
    }, "myRTMPSDK", "play", [play_type,play_url]);
};

Play.watch = function(play_type,play_url) {
    exec(function () {
        alert("success");
    }, function (error_essage) {
        alert(error_essage)
    }, "myRTMPSDK", "watch", [play_type,play_url]);
};

/*
 Keyboard.styleDark = function(dark) {
 exec(null, null, "Keyboard", "styleDark", [dark]);
 };
 */

module.exports = Play;





