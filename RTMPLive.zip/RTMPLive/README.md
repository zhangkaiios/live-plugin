进行直播方法：
RTMPLive的play方法，参数1：1 参数2：直播链接（如：rtmp://2132.livepush.myqcloud.com/live/2132_cc56f101a62a11e69776e435c87f075e?bizid=2132）

观看直播和点播的方法：

RTMPLive的watch方法,参数1：视频格式（0：RTMP直播 1：FLV直播 2：FLV点播 3：HLS点播 4：MP4点播） 参数2：视频地址

