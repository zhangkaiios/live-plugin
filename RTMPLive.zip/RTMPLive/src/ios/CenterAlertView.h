//
//  CenterAlertView.h
//  ZhiBoBa
//
//  Created by 圣殿骑士 on 2016/11/21.
//  Copyright © 2016年 yuwei. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^VoidReturnBlock)(void);
@interface CenterAlertView : UIView
@property (nonatomic, copy) VoidReturnBlock returnBlock;
@property (weak, nonatomic) IBOutlet UILabel *titileLabel; // 标题
@property (weak, nonatomic) IBOutlet UILabel *contextLabel; // 内容
@property (weak, nonatomic) IBOutlet UIButton *enterBtu; // 确定
@property (weak, nonatomic) IBOutlet UIButton *cancelBtu; // 取消
- (void)initWithSuperView:(UIView *)superView Enter:(void (^)(void))enter;

@end
