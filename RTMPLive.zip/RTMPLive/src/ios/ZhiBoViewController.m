

#import "ZhiBoViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "TXRTMPSDK/TXLivePush.h"
#import "CenterAlertView.h"
#define SCREEN_HEIGHT   [[UIScreen mainScreen] bounds].size.height
#define SCREEN_WIDTH    [[UIScreen mainScreen] bounds].size.width
@interface ZhiBoViewController ()<TXLivePushListener,NSURLSessionDelegate>
{
    BOOL _camera_switch;
    BOOL _closeVoice;
    BOOL _openSGD;
    BOOL nowIsShare;
    UIButton *sgdButton;
    UIButton *voiceButton;
    UIButton*    _btnCamera;
    UILabel *timeLabel;
    NSInteger timeNumber;
    TXLivePush *_txLivePush;
    UIView *    preViewContainer;
    UIView *lineUps;
    UIView *lineUps2;
    UIView *lineUp;
    NSTimer * timer;
}
@property(nonatomic,weak)UIView *myView;
@property (strong,nonatomic) UIImagePickerController* imagePicker;
@property (nonatomic, assign) UIDeviceOrientation  orient;
@property (nonatomic, copy) NSDictionary *dataDic;
@end

@implementation ZhiBoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _orient = UIDeviceOrientationPortrait;
    
    TXLivePushConfig* _config = [[TXLivePushConfig alloc] init];
    //    _config.watermark = [UIImage imageNamed:@"watermark.png"];
    //    _config.watermarkPos = (CGPoint){10, 10};
    _txLivePush = [[TXLivePush alloc] initWithConfig:_config];
    
    [_txLivePush setLogLevel:LOGLEVEL_DEBUG];
    self.view.backgroundColor = [UIColor whiteColor];
    //创建直播的View
    [self createView];
    //创建Push对象
    [self createPush];
    if (_pushUrl && _pushUrl.length > 10) {
        //启动推流
        [self startPush];
    }
}
- (void)viewDidAppear:(BOOL)animated
{
    [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
}
- (void)viewWillAppear:(BOOL)animated
{

}
- (void)viewWillDisappear:(BOOL)animated
{
    [[UIApplication sharedApplication] setIdleTimerDisabled:NO];
}
#pragma mark - Carame

- (void) toastTip:(NSString*)toastInfo
{
    CGRect frameRC = [[UIScreen mainScreen] bounds];
    frameRC.origin.y = frameRC.size.height - 110;
    frameRC.size.height -= 110;
    __block UITextView * toastView = [[UITextView alloc] init];
    
    toastView.editable = NO;
    toastView.selectable = NO;
    
    frameRC.size.height = [self heightForString:toastView andWidth:frameRC.size.width];
    toastView.frame = frameRC;
    
    toastView.text = toastInfo;
    toastView.backgroundColor = [UIColor whiteColor];
    toastView.alpha = 0.5;
    
    [self.view addSubview:toastView];
    
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC);
    
    dispatch_after(popTime, dispatch_get_main_queue(), ^(){
        [toastView removeFromSuperview];
        toastView = nil;
    });
}
- (float) heightForString:(UITextView *)textView andWidth:(float)width{
    CGSize sizeToFit = [textView sizeThatFits:CGSizeMake(width, MAXFLOAT)];
    return sizeToFit.height;
}
-(void)createView{
    CGRect previewFrame = self.view.bounds;
    preViewContainer = [[UIView alloc] initWithFrame:previewFrame];
    
    [self.view insertSubview:preViewContainer atIndex:0];
    preViewContainer.center = self.view.center;
}

-(void)createPush{
    //控制条
    lineUp = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_HEIGHT, 50)];
    [self.view addSubview:lineUp];
    // 停播
    UIButton *stopButton = [[UIButton alloc]initWithFrame:CGRectMake(lineUp.frame.size.width - 95, 12, 81, 30)];
    stopButton.backgroundColor = [UIColor redColor];
    [stopButton setTitle:@"X 停播" forState:UIControlStateNormal];
    [stopButton setTitleColor:[UIColor whiteColor] forState:(UIControlStateNormal)];
    [stopButton addTarget:self action:@selector(stopLive) forControlEvents:UIControlEventTouchUpInside];
    [lineUp addSubview:stopButton];
        // 设置圆角
        [stopButton.layer setMasksToBounds:YES];
        [stopButton.layer setCornerRadius:12.5];
    //前置后置摄像头切换
    _camera_switch = NO;
    _btnCamera = [UIButton buttonWithType:UIButtonTypeCustom];
    _btnCamera.frame = CGRectMake(stopButton.frame.origin.x - 45, stopButton.frame.origin.y, 30, 30);
    [_btnCamera setImage:[UIImage imageNamed:@"xiangji"] forState:UIControlStateNormal];
    [_btnCamera addTarget:self action:@selector(clickCamera:) forControlEvents:UIControlEventTouchUpInside];
    [lineUp addSubview:_btnCamera];
    // 静音
    voiceButton = [[UIButton alloc]initWithFrame:CGRectMake(_btnCamera.frame.origin.x - 45, _btnCamera.frame.origin.y, 30, 30)];
    [voiceButton setImage:[UIImage imageNamed:@"maikefeng"] forState:UIControlStateNormal];
    [voiceButton addTarget:self action:@selector(stopvoice) forControlEvents:UIControlEventTouchUpInside];
    [lineUp addSubview:voiceButton];
    // 闪光灯
    sgdButton = [[UIButton alloc]initWithFrame:CGRectMake(voiceButton.frame.origin.x - 45, voiceButton.frame.origin.y, 30, 30)];
    [sgdButton setImage:[UIImage imageNamed:@"sanguangdeng - Assistor"] forState:UIControlStateNormal];
    [sgdButton addTarget:self action:@selector(sanguangdeng) forControlEvents:UIControlEventTouchUpInside];
    [lineUp addSubview:sgdButton];
    
    UIButton *sharebutton = [[UIButton alloc]initWithFrame:CGRectMake(sgdButton.frame.origin.x - 45, 12, 30, 30)];
    [sharebutton setImage:[UIImage imageNamed:@"share"] forState:UIControlStateNormal];
    [sharebutton addTarget:self action:@selector(shareAction) forControlEvents:UIControlEventTouchUpInside];
    [lineUp addSubview:sharebutton];

    timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(30, 12, 85, 30)];
    timeLabel.text = @"00:00:00";
    timeLabel.numberOfLines = 0;
    
    timeLabel.backgroundColor =  [UIColor colorWithRed:55/255.0 green:55/255.0 blue:55/255.0 alpha:1]; //COLOR_A(55, 55, 55, 0.8);
    timeLabel.font = [UIFont systemFontOfSize:15];
    timeLabel.textAlignment = NSTextAlignmentCenter;
    [lineUp addSubview:timeLabel];
        // 设置圆角
        [timeLabel.layer setMasksToBounds:YES];
        [timeLabel.layer setCornerRadius:15];
        // 设置边框
        [timeLabel.layer setBorderWidth:1];
        CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
        CGColorRef colorref = CGColorCreate(colorSpace,(CGFloat[]){ 250/255.0, 250/255.0, 250/255.0, 1 });
        [timeLabel.layer setBorderColor:colorref];//边框颜色
    timeLabel.textColor = [UIColor whiteColor];
    
    lineUp.transform = CGAffineTransformMakeRotation(90*M_PI/180);
    lineUp.center = CGPointMake(SCREEN_WIDTH - 25, SCREEN_HEIGHT/2);
    [[UIApplication sharedApplication] setStatusBarHidden:TRUE];
    [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
}
- (void)shareAction{
   
}
// 闪光灯
- (void)sanguangdeng
{
    _openSGD = !_openSGD;
    if (_openSGD) {
        [_txLivePush toggleTorch:YES];
        [sgdButton setImage:[UIImage imageNamed:@"sanguangdeng"] forState:(UIControlStateNormal)];
    }else{
        [_txLivePush toggleTorch:NO];
        [sgdButton setImage:[UIImage imageNamed:@"sanguangdeng - Assistor"] forState:(UIControlStateNormal)];
    }
}
// 停止声音
- (void)stopvoice
{
    _closeVoice = !_closeVoice;
    if (_closeVoice) {
        [_txLivePush setMute:YES];
        [voiceButton setImage:[UIImage imageNamed:@"maikefeng - Assistor"] forState:(UIControlStateNormal)];
    }else{
        [_txLivePush setMute:NO];
        [voiceButton setImage:[UIImage imageNamed:@"maikefeng"] forState:(UIControlStateNormal)];
    }
}
// 停播
- (void)stopLive
{
    CenterAlertView *alert=[[[NSBundle mainBundle] loadNibNamed:@"CenterAlert" owner:self options:nil] lastObject];
    alert.contextLabel.text = @"是否要退出直播";
    [alert initWithSuperView:self.view Enter:^{
        [_txLivePush stopPush];
        [timer invalidate];
        timer = nil;
        [[UIApplication sharedApplication] setIdleTimerDisabled:NO];
        [[UIApplication sharedApplication] setStatusBarHidden:NO];
        [self dismissViewControllerAnimated:YES completion:^{
            
        }];
    }];
    switch (_orient)
    {
        case UIDeviceOrientationLandscapeLeft:
            alert.transform = CGAffineTransformMakeRotation(90*M_PI/180);
            break;
        case UIDeviceOrientationLandscapeRight:
            alert.transform = CGAffineTransformMakeRotation(-90*M_PI/180);
            break;
        default:
            break;
    }
}
#pragma mark - 切摄像头
-(void) clickCamera:(UIButton*) btn
{
    _camera_switch = !_camera_switch;
//    TXLivePushConfig* _config = _txLivePush.config;
//    _config.pauseFps = 20;
//    _config.pauseTime = 300;
//    if (_camera_switch) {
//        _config.homeOrientation = HOME_ORIENTATION_LEFT;
//        [_txLivePush setRenderRotation:90];
//    }else{
//        _config.homeOrientation = HOME_ORIENTATION_LEFT;
//        [_txLivePush setRenderRotation:90];
//    }
    [btn setImage:[UIImage imageNamed:(_camera_switch? @"xiangji" : @"xiangji")] forState:UIControlStateNormal];
    [_txLivePush switchCamera];
//    _config.pauseImg = [UIImage imageNamed:@"pause_publish.jpg"];
//    [_txLivePush setConfig:_config];
}
- (void)startTimer{
    if (!timer) {
        timer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(timeCounter) userInfo:nil repeats:YES];
    }
}
- (void)timeCounter{
    timeLabel.text = [self nowTimeWithTimeNumber:timeNumber];
    timeNumber++;
}
- (NSString *)nowTimeWithTimeNumber:(NSInteger)Timernumber
{
    NSInteger hour = Timernumber/3600;
    NSInteger minte =Timernumber%3600/60;
    NSInteger ss = Timernumber%3600%60;
    NSString *time = [NSString stringWithFormat:@"%02ld:%02ld:%02ld",(long)hour,minte,ss];
    return time;
}
-(void)startPush{
    AVAuthorizationStatus statusVideo = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if (statusVideo == AVAuthorizationStatusDenied) {
        [self toastTip:@"获取摄像头权限失败，请前往隐私-相机设置里面打开应用权限"];
        return;
    }
    //是否有麦克风权限
    AVAuthorizationStatus statusAudio = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio];
    if (statusAudio == AVAuthorizationStatusDenied) {
        [self toastTip:@"获取麦克风权限失败，请前往隐私-麦克风设置里面打开应用权限"];
        return;
    }
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleEnterBackground:) name:UIApplicationDidEnterBackgroundNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleEnterForeground:) name:UIApplicationWillEnterForegroundNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(Terminate:) name:UIApplicationWillTerminateNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(orientChange:) name:UIDeviceOrientationDidChangeNotification object:nil];

    // 创建 LivePushConfig 对象，该对象默认初始化为基础配置
    //在 _config中您可以对推流的参数（如：美白，硬件加速，前后置摄像头等）做一些初始化操作，需要注意 _config不能为nil
    TXLivePushConfig* _config = _txLivePush.config;
    _config.pauseFps = 20;
    _config.pauseTime = 300;
//    _config.homeOrientation = HOME_ORIENTATION_LEFT;
//    [_txLivePush setRenderRotation:90];
    _config.pauseImg = [UIImage imageNamed:@"pause_publish.jpg"];
    [_txLivePush setConfig:_config];
    
    _txLivePush.delegate = self;

    if (!_isPreviewing) {
        [_txLivePush startPreview:preViewContainer];
        _isPreviewing = YES;
    }
    if ([_txLivePush startPush:_pushUrl] != 0) {
        NSLog(@"推流器启动失败");
    }
    
//    TXLivePushConfig* _config = [[TXLivePushConfig alloc]init];
//    _config.pauseFps = 10;
//    _config.pauseTime = 300;
//    _config.homeOrientation = HOME_ORIENTATION_LEFT;
//    _config.pauseImg = [UIImage imageNamed:@"pause_publish.jpg"];
//    _txLivePush = [[TXLivePush alloc] initWithConfig:_config];
//    _txLivePush.delegate = self;
//    [_txLivePush setLogLevel:0];
//    [_txLivePush setRenderRotation:HOME_ORIENTATION_RIGHT];
//    [_txLivePush setConfig:_config];
//    [_txLivePush startPreview:_myView];  //_myView 就是step2中需要您指定的view
//    [_txLivePush startPush:_pushUrl];
//    [_txLivePush switchCamera];
}
- (void)Terminate:(NSNotification *)noti
{

}

#pragma mark - 屏幕旋转
- (void)orientChange:(NSNotification *)noti
{
    UIDeviceOrientation  orient = [UIDevice currentDevice].orientation;
    //[GlobalUtil HUDShowMessage:@"屏幕旋转1" addedToView:self.view];
    switch (orient)
    {
        case UIDeviceOrientationPortrait:{
//            TXLivePushConfig* _config = _txLivePush.config;
//            _config.homeOrientation = HOME_ORIENTATION_DOWN;
//            [_txLivePush setConfig:_config];
//            [_txLivePush setRenderRotation:90];
            _orient = UIDeviceOrientationPortrait;
        }
            break;
        case UIDeviceOrientationLandscapeLeft:{
//            TXLivePushConfig* _config = _txLivePush.config;
//            _config.homeOrientation = HOME_ORIENTATION_LEFT;
//            [_txLivePush setConfig:_config];
//            [_txLivePush setRenderRotation:90];
            lineUp.transform = CGAffineTransformMakeRotation(90*M_PI/180);
            lineUp.center = CGPointMake(SCREEN_WIDTH - 25, SCREEN_HEIGHT/2);
            _orient = UIDeviceOrientationLandscapeLeft;
        }
            break;
        case UIDeviceOrientationPortraitUpsideDown:
        {

        }
            break;
        case UIDeviceOrientationLandscapeRight:
        {
            lineUp.transform = CGAffineTransformMakeRotation(-90*M_PI/180);
            lineUp.center = CGPointMake(25, SCREEN_HEIGHT/2);
//            TXLivePushConfig* _config = _txLivePush.config;
//            _config.homeOrientation = HOME_ORIENTATION_RIGHT;
//            [_txLivePush setConfig:_config];
//            [_txLivePush setRenderRotation:90];
            _orient = UIDeviceOrientationLandscapeRight;
        }
            break;
            
        default:
            break;
    }
}

- (void)handleEnterBackground:(NSNotification *)notification
{
    [[UIApplication sharedApplication] beginBackgroundTaskWithExpirationHandler:^{
        
    }];
    if (!nowIsShare) {
       [_txLivePush pausePush];
    }
    
}
-(void) onPushEvent:(int)EvtID withParam:(NSDictionary*)param
{
    switch (EvtID) {
        case 1003:{
            // 开始事件
            [self startTimer];
        }
            break;
        default:
            break;
    }
}
-(void) onNetStatus:(NSDictionary*) param
{

}
- (void)handleEnterForeground:(NSNotification *)notification
{
    nowIsShare = NO;
    [_txLivePush resumePush];
}

@end
