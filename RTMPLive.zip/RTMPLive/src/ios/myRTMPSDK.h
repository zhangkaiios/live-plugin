//
//  RTMPSDK.h
//  Workshop
//
//  Created by 圣殿骑士 on 2016/12/12.
//
//

#import <Cordova/CDVPlugin.h>

@interface myRTMPSDK : CDVPlugin
- (void)play:(CDVInvokedUrlCommand*)command;
- (void)watch:(CDVInvokedUrlCommand*)command;
@end
