//
//  ZhiBoViewController.h
//  ZhiBoBa
//
//  Created by zhuyk on 16/11/11.
//  Copyright © 2016年 yuwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZhiBoViewController : UIViewController
{
    BOOL            _isPreviewing;
}
@property (nonatomic, copy) NSString *pushid;
@property (nonatomic, copy) NSString *pushUrl;
@end
