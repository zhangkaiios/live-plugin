//
//  WatchLiveVC.m
//  Workshop
//
//  Created by 圣殿骑士 on 2016/12/14.
//
//

#import "WatchLiveVC.h"

@interface WatchLiveVC ()
@property (nonatomic, strong) TXLivePlayer *txLivePlayer;
@end

@implementation WatchLiveVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _txLivePlayer = [[TXLivePlayer alloc] init];
    [_txLivePlayer setupVideoWidget:self.view.bounds containView:self.view insertIndex:0];
    TXLivePlayConfig*  _config = [[TXLivePlayConfig alloc] init];
    //流畅模式
    _config.bAutoAdjustCacheTime   = YES;
    // txLivePlayer.delegate = self;
    [_txLivePlayer setRenderMode:RENDER_MODE_FILL_SCREEN];
    [_txLivePlayer setConfig:_config];
    
    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(10, 10, 25, 25)];
    [button setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
}
- (void)back{
    [self dismissViewControllerAnimated:YES completion:^{
            
    }];
}
- (void)watchLiveWithUrl:(NSString *)url type:(int)type
{
    if (type == 0) {
        [_txLivePlayer startPlay:url type:PLAY_TYPE_LIVE_RTMP];
    }else if(type == 1){
        [_txLivePlayer startPlay:url type:PLAY_TYPE_LIVE_FLV];
    }else if (type == 2){
        [_txLivePlayer startPlay:url type:PLAY_TYPE_VOD_FLV];
    }else if (type == 3){
        [_txLivePlayer startPlay:url type:PLAY_TYPE_VOD_HLS];
    }else if (type == 4){
        [_txLivePlayer startPlay:url type:PLAY_TYPE_VOD_MP4];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
