//
//  RTMPSDK.m
//  Workshop
//
//  Created by 圣殿骑士 on 2016/12/12.
//
//

#import "myRTMPSDK.h"
#import "ZhiBoViewController.h"
#import "WatchLiveVC.h"

@implementation myRTMPSDK
- (void)play:(CDVInvokedUrlCommand*)command
{
    NSInteger type = [command.arguments[0] integerValue];
    
    ZhiBoViewController *watch = [[ZhiBoViewController alloc] init];
    watch.pushUrl = command.arguments[1];
    [self.viewController presentViewController:watch animated:YES completion:nil];
    if (type == 1){
        
    } else if (type == 2) {
        
    }
}
- (void)watch:(CDVInvokedUrlCommand*)command
{
    int type = [command.arguments[0] intValue];
        
    WatchLiveVC *watch = [[WatchLiveVC alloc] init];
    [watch watchLiveWithUrl:command.arguments[1] type:type];
    [self.viewController presentViewController:watch animated:YES completion:nil];
    if (type == 1){
            
    }else if (type == 2) {
            
    }
}
@end
