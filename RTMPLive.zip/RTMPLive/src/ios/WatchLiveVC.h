//
//  WatchLiveVC.h
//  Workshop
//
//  Created by 圣殿骑士 on 2016/12/14.
//
//

#import <UIKit/UIKit.h>
#import "TXRTMPSDK/TXLivePlayer.h"

@interface WatchLiveVC : UIViewController
- (void)watchLiveWithUrl:(NSString *)url type:(int)type;
@end
