//
//  CenterAlertView.m
//  ZhiBoBa
//
//  Created by 圣殿骑士 on 2016/11/21.
//  Copyright © 2016年 yuwei. All rights reserved.
//

#import "CenterAlertView.h"

@implementation CenterAlertView

- (void)initWithSuperView:(UIView *)superView Enter:(void (^)(void))enter
{
        self.frame = CGRectMake(0, 0, 1000, 1000);
        self.center = CGPointMake(superView.frame.size.width/2, superView.frame.size.height/2);
        [superView addSubview:self];
        _returnBlock = enter;
}
- (IBAction)cancelAction:(id)sender {
    [self removeFromSuperview];
}
- (IBAction)enterAction:(id)sender {
    self.hidden = YES;
    if (_returnBlock) {
        _returnBlock();
    }
}

@end
